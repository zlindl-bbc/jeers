create view v_rechte as
  select
    `jeers`.`person`.`EMAIL`    AS `EMAIL`,
    `jeers`.`person`.`PASSWORT` AS `PASSWORT`,
    `jeers`.`rolle`.`NAME`      AS `ROLLE`
  from ((`jeers`.`person`
    join `jeers`.`person_rolle` on ((`jeers`.`person`.`ID` = `jeers`.`person_rolle`.`PERSON_FK`))) join `jeers`.`rolle`
      on ((`jeers`.`rolle`.`ID` = `jeers`.`person_rolle`.`ROLLE_FK`)));

